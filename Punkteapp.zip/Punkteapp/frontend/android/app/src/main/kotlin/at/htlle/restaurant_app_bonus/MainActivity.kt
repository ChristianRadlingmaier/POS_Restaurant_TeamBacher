package at.htlle.restaurant_app_bonus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
