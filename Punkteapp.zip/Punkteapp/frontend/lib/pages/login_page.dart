import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);

    final url = Uri.parse("http://192.168.5.155:8080/api/auth/login");
    // ↑ DEINE IPv4 eintragen (die, die mit Postman funktioniert)

    final body = jsonEncode({
      "email": emailController.text,
      "password": passwordController.text,
    });

    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: body,
    );

    setState(() => loading = false);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);

      final token = json["token"];
      final email = json["email"];
      final isAdmin = json["admin"];

      print("TOKEN: $token");
      print("EMAIL: $email");
      print("ADMIN: $isAdmin");

      Navigator.pushReplacementNamed(context, "/rewards");
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Login fehlgeschlagen")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Anmeldung")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: "E-Mail"),
            ),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: "Passwort"),
              obscureText: true,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: loading ? null : login,
              child: loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Einloggen"),
            ),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, "/register"),
              child: const Text("Noch kein Konto? Registrieren"),
            ),
          ],
        ),
      ),
    );
  }
}
