package at.htlle.Punkteapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PunkteappApplicationTests {

	@Test
	void contextLoads() {
	}

}
