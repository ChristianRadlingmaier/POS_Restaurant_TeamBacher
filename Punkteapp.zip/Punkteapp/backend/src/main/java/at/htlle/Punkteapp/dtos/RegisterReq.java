package at.htlle.Punkteapp.dtos;

public record RegisterReq(String firstname,String lastname,String email,String password) {}