package at.htlle.Punkteapp.dtos;

public record RewardRedeemReq(Long rewardId) {}