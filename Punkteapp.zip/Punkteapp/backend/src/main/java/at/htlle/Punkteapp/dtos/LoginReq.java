package at.htlle.Punkteapp.dtos;

public record LoginReq(String email,String password) {}