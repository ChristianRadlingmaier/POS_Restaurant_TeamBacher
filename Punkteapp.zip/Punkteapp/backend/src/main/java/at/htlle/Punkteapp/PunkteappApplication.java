package at.htlle.Punkteapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PunkteappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PunkteappApplication.class, args);
	}

}
