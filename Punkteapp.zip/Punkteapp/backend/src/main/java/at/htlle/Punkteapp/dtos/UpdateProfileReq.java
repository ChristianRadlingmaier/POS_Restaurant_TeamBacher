package at.htlle.Punkteapp.dtos;

public record UpdateProfileReq(String firstname,String lastname,String email,String password) {}