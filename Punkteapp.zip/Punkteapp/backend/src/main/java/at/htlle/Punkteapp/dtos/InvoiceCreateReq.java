package at.htlle.Punkteapp.dtos;

public record InvoiceCreateReq(Integer pointsEarned) {}