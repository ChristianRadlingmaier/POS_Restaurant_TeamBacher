package at.htlle.Punkteapp.dtos;

public record RewardDTO(Long rewardId, String title, Boolean status, String description, Integer pointsCost){}